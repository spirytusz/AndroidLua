function getStringFromJava()
	return getString()
end