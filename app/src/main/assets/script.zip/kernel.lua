
function __TRACKBACK__(msg)
	lua_log("----------------------------------------")
    lua_log("LUA ERROR: " .. tostring(msg) .. "\n")
    lua_log(debug.traceback())
    lua_log("----------------------------------------")
end

function lua_log(fmt, ...)
	local args = {...}
	CPrintMsg(string.format(fmt, table.unpack(args)))
end

function lua_sleepSeconds(seconds)
	sleepSeconds(seconds)
end

function lua_sleepMilliseconds(milliseconds)
	sleepMilliseconds(milliseconds)
end