
function main()
	while true do
		for i=1,10 do
			lua_log('%s %d', getStringFromJava(), i)
			lua_log('getData: %s', getData('res/0028'))
			lua_sleepMilliseconds(500)
		end
		lua_sleepSeconds(1)
	end
end